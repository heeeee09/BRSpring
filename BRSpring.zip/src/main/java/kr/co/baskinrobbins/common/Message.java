package kr.co.baskinrobbins.common;

public class Message {
	
	String message = "";
	String href = "";
	
	public Message(String message, String href) {
		this.message = message;
		this.href = href;
	}

}
